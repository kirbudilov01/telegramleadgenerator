#!/bin/bash
set -e
cd "$(dirname "$0")"
source venv/bin/activate
python autopilot.py --once --dry-run --profile safe --verbose
