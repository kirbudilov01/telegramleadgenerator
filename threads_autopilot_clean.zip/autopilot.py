import argparse
import asyncio
import json
import logging
import random
import re
import sys
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from urllib.parse import quote
from urllib.request import Request, urlopen

from playwright.async_api import async_playwright, Page, BrowserContext

BASE_DIR = Path(__file__).parent
CONFIG_FILE = BASE_DIR / "config.json"
STATE_FILE = BASE_DIR / "state.json"
STORAGE_STATE_FILE = BASE_DIR / "threads_storage_state.json"
PERSONA_FILE = BASE_DIR / "persona.txt"
LOG_FILE = BASE_DIR / "autopilot.log"

PROFILE_PRESETS = {
    "safe": {
        "cycle_minutes": 30,
        "cycle_jitter_minutes": [2, 8],
        "max_replies_per_cycle": 1,
        "max_replies_per_day": 20,
        "reply_delay_seconds": [30, 120],
        "search_posts_per_keyword": 20,
        "llm_min_score": 0.78,
    },
    "balanced": {
        "cycle_minutes": 20,
        "cycle_jitter_minutes": [1, 6],
        "max_replies_per_cycle": 2,
        "max_replies_per_day": 40,
        "reply_delay_seconds": [20, 90],
        "search_posts_per_keyword": 30,
        "llm_min_score": 0.72,
    },
    "aggressive": {
        "cycle_minutes": 15,
        "cycle_jitter_minutes": [1, 4],
        "max_replies_per_cycle": 3,
        "max_replies_per_day": 60,
        "reply_delay_seconds": [15, 70],
        "search_posts_per_keyword": 40,
        "llm_min_score": 0.68,
    },
}


@dataclass
class CandidatePost:
    keyword: str
    post_url: str
    author_url: str
    author_handle: str
    text: str


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def setup_logging(verbose: bool) -> None:
    handlers = [logging.FileHandler(LOG_FILE, encoding="utf-8"), logging.StreamHandler(sys.stdout)]
    logging.basicConfig(
        level=logging.DEBUG if verbose else logging.INFO,
        format="%(asctime)s [%(levelname)s] %(message)s",
        handlers=handlers,
    )


def read_json(path: Path, default: Any) -> Any:
    if not path.exists():
        return default
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default


def write_json(path: Path, data: Any) -> None:
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def load_config() -> dict:
    cfg = read_json(CONFIG_FILE, None)
    if cfg is None:
        raise RuntimeError(
            f"Missing {CONFIG_FILE.name}. Copy config.example.json to config.json and fill values."
        )
    return cfg


def load_persona(path: Path) -> str:
    if not path.exists():
        return "You are a senior software engineer and product builder."
    return path.read_text(encoding="utf-8").strip()


def load_state() -> dict:
    state = read_json(
        STATE_FILE,
        {
            "seen_posts": [],
            "replied_posts": [],
            "daily_stats": {},
            "last_reply_ts": 0,
            "reply_history": [],
            "keyword_history": [],
        },
    )
    for key in ["seen_posts", "replied_posts", "reply_history", "keyword_history"]:
        if key not in state:
            state[key] = []
    if "daily_stats" not in state:
        state["daily_stats"] = {}
    if "last_reply_ts" not in state:
        state["last_reply_ts"] = 0
    return state


def save_state(state: dict) -> None:
    write_json(STATE_FILE, state)


def dedupe_keep_tail(items: list[str], max_items: int) -> list[str]:
    seen = set()
    result = []
    for item in reversed(items):
        if item in seen:
            continue
        seen.add(item)
        result.append(item)
    return list(reversed(result))[-max_items:]


class OllamaClient:
    def __init__(self, host: str, model: str, timeout_seconds: int = 45):
        self.host = host.rstrip("/")
        self.model = model
        self.timeout_seconds = timeout_seconds

    def _chat(self, prompt: str) -> str:
        payload = {
            "model": self.model,
            "messages": [{"role": "user", "content": prompt}],
            "stream": False,
            "options": {"temperature": 0.2},
        }
        req = Request(
            f"{self.host}/api/chat",
            data=json.dumps(payload).encode("utf-8"),
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urlopen(req, timeout=self.timeout_seconds) as resp:
            raw = json.loads(resp.read().decode("utf-8"))
        return raw.get("message", {}).get("content", "").strip()

    def classify(self, post_text: str, keyword: str) -> dict:
        prompt = f"""
You are classifying social media posts for lead generation.
Return ONLY JSON with keys:
- relevant: boolean
- score: number between 0 and 1
- reason: short string

Criteria for relevant=true:
- Post asks for developer, IT specialist, AI engineer, app/web/telegram development,
  or requests technical partner / contractor / team.
- The post has clear hiring/build intent.

Keyword: {keyword}
Post text:
<<<POST>>>
{post_text[:800]}
<<<END_POST>>>
"""
        try:
            out = self._chat(prompt)
        except Exception:
            return {"relevant": False, "score": 0.0, "reason": "ollama_unavailable"}
        m = re.search(r"\{.*\}", out, flags=re.DOTALL)
        if not m:
            return {"relevant": False, "score": 0.0, "reason": "llm_non_json"}
        try:
            data = json.loads(m.group(0))
            return {
                "relevant": bool(data.get("relevant", False)),
                "score": float(data.get("score", 0.0)),
                "reason": str(data.get("reason", ""))[:200],
            }
        except Exception:
            return {"relevant": False, "score": 0.0, "reason": "llm_parse_error"}

    def generate_keywords(self, base_keywords: list[str], persona: str, max_new: int) -> list[str]:
        prompt = f"""
Generate additional search keywords for Threads lead generation.
Return ONLY JSON array of strings. No explanation.
Limit: {max_new} items.
Language mix: Russian + English.
Avoid duplicates with base list.

Base keywords:
{json.dumps(base_keywords, ensure_ascii=False)}

Persona summary:
{persona[:700]}
"""
        try:
            out = self._chat(prompt)
        except Exception:
            return []
        m = re.search(r"\[.*\]", out, flags=re.DOTALL)
        if not m:
            return []
        try:
            arr = json.loads(m.group(0))
            clean = []
            for item in arr:
                if isinstance(item, str) and item.strip():
                    clean.append(item.strip())
            return clean[:max_new]
        except Exception:
            return []

    def compose_reply(self, persona: str, post_text: str, author_handle: str) -> str:
        prompt = f"""
You write concise outreach comments for Threads.
Goal: start conversation naturally without spam.

Rules:
- 1 short comment, max 300 chars.
- No hashtags.
- No links.
- Friendly, useful, human tone.
- Mention concrete fit from post text.
- End with soft CTA to continue in DM.
- Language should match post language.

Persona:
{persona[:900]}

Author: {author_handle}
Post:
<<<POST>>>
{post_text[:900]}
<<<END_POST>>>

Return only the final comment text.
"""
        try:
            out = self._chat(prompt)
        except Exception:
            return ""
        result = out.strip().strip('"')
        return re.sub(r"\s+", " ", result)[:300]


def simple_relevance_rule(text: str) -> dict:
    txt = text.lower()
    intent = [
        "ищу", "нужен", "нужна", "требуется", "looking for", "need", "hire", "hiring",
        "задача", "подрядчик", "фриланс", "в штат",
    ]
    domain = [
        "it", "ии", "ai", "app", "web", "telegram", "телеграм", "бот", "developer",
        "разработчик", "программист", "приложение", "сайт", "mvp", "automation",
    ]
    ok = any(w in txt for w in intent) and any(w in txt for w in domain)
    return {"relevant": ok, "score": 0.65 if ok else 0.05, "reason": "rule_filter"}


def normalize_handle(author_url: str) -> str:
    if not author_url:
        return ""
    m = re.search(r"threads\.net/@([^/?#]+)", author_url)
    if not m:
        return ""
    return "@" + m.group(1)


def make_post_id(post_url: str, text: str) -> str:
    if post_url:
        m = re.search(r"threads\.net(/[^?#]+)", post_url)
        if m:
            return m.group(1)
    return text[:120].strip().lower()


async def build_context(cfg: dict, headful_override: bool | None = None) -> tuple[Any, BrowserContext]:
    headful = cfg.get("headful", True) if headful_override is None else headful_override
    window = cfg.get("window", {"x": 0, "y": 0, "width": 960, "height": 1080})

    pw = await async_playwright().start()
    args = [
        f"--window-position={int(window.get('x', 0))},{int(window.get('y', 0))}",
        f"--window-size={int(window.get('width', 960))},{int(window.get('height', 1080))}",
    ]

    browser = await pw.chromium.launch(headless=not headful, args=args)
    context = await browser.new_context(storage_state=str(STORAGE_STATE_FILE) if STORAGE_STATE_FILE.exists() else None)
    return pw, context


async def setup_login(cfg: dict) -> None:
    logging.info("Opening browser for one-time Threads login...")
    pw, context = await build_context(cfg, headful_override=True)
    page = await context.new_page()
    await page.goto("https://www.threads.net/login", wait_until="domcontentloaded")
    print("\nFinish login in opened browser, then press Enter here.")
    input()
    await context.storage_state(path=str(STORAGE_STATE_FILE))
    await context.close()
    await pw.stop()
    logging.info("Saved login storage state: %s", STORAGE_STATE_FILE)


async def scrape_posts_for_keyword(page: Page, keyword: str, max_posts: int) -> list[CandidatePost]:
    search_url = f"https://www.threads.net/search?q={quote(keyword)}&serp_type=default"
    try:
        await page.goto(search_url, wait_until="domcontentloaded", timeout=45000)
        for _ in range(6):
            await page.evaluate("window.scrollTo(0, document.body.scrollHeight)")
            await page.wait_for_timeout(random.randint(1200, 2200))

        raw = await page.evaluate(
            """() => {
                const out = [];
                const seen = new Set();
                const blocks = document.querySelectorAll('article, [role="article"]');
                for (const block of blocks) {
                  const textEl = block.querySelector('[dir="auto"]');
                  const text = textEl ? textEl.innerText.trim() : '';
                  if (!text || text.length < 25) continue;
                  const postLink = block.querySelector('a[href*="/post/"]');
                  const authorLink = block.querySelector('a[href*="/@"]');
                  const postUrl = postLink ? postLink.href : '';
                  const authorUrl = authorLink ? authorLink.href : '';
                  const key = postUrl || text.slice(0, 100);
                  if (seen.has(key)) continue;
                  seen.add(key);
                  out.push({postUrl, authorUrl, text});
                }
                return out;
            }"""
        )
    except Exception as exc:
        logging.warning("Search failed for keyword '%s': %s", keyword, exc)
        return []

    candidates: list[CandidatePost] = []
    for item in raw[:max_posts]:
        post_url = item.get("postUrl", "")
        author_url = item.get("authorUrl", "")
        text = item.get("text", "")
        candidates.append(
            CandidatePost(
                keyword=keyword,
                post_url=post_url,
                author_url=author_url,
                author_handle=normalize_handle(author_url),
                text=text,
            )
        )
    return candidates


async def post_reply(page: Page, post_url: str, reply_text: str) -> tuple[bool, str]:
    try:
        await page.goto(post_url, wait_until="domcontentloaded", timeout=45000)
        await page.wait_for_timeout(random.randint(1200, 2500))

        reply_button_selectors = [
            "button:has-text('Reply')",
            "div[role='button']:has-text('Reply')",
            "div[aria-label*='Reply']",
        ]
        clicked = False
        for sel in reply_button_selectors:
            loc = page.locator(sel)
            if await loc.count() > 0:
                await loc.first.click(timeout=3000)
                clicked = True
                break
        if not clicked:
            return False, "reply_button_not_found"

        await page.wait_for_timeout(random.randint(800, 1800))
        box_selectors = [
            "div[role='textbox']",
            "textarea",
            "div[contenteditable='true']",
        ]
        typed = False
        for sel in box_selectors:
            box = page.locator(sel)
            if await box.count() > 0:
                await box.first.fill(reply_text)
                typed = True
                break
        if not typed:
            return False, "reply_box_not_found"

        await page.wait_for_timeout(random.randint(900, 1800))
        send_selectors = [
            "button:has-text('Post')",
            "div[role='button']:has-text('Post')",
            "button:has-text('Reply')",
        ]
        sent = False
        for sel in send_selectors:
            btn = page.locator(sel)
            if await btn.count() > 0:
                await btn.first.click(timeout=4000)
                sent = True
                break
        if not sent:
            return False, "send_button_not_found"

        await page.wait_for_timeout(random.randint(1800, 3000))
        return True, "ok"
    except Exception as exc:
        return False, f"exception:{exc}"


def resolve_keywords(cfg: dict, persona: str, ollama: OllamaClient | None, state: dict) -> list[str]:
    base = [k.strip() for k in cfg.get("keywords", []) if k.strip()]
    if not base:
        base = ["it", "ai", "web", "app", "telegram", "телеграм", "ии"]

    result = list(base)
    if cfg.get("auto_keyword_generation", True) and ollama:
        max_new = int(cfg.get("generated_keywords", 6))
        generated = ollama.generate_keywords(base, persona, max_new=max_new)
        result.extend(generated)

    result = dedupe_keep_tail(result, int(cfg.get("keyword_limit", 20)))
    state["keyword_history"] = dedupe_keep_tail(state.get("keyword_history", []) + result, 500)
    return result


def can_reply_today(state: dict, max_replies_day: int) -> bool:
    day = datetime.now().strftime("%Y-%m-%d")
    day_count = int(state.get("daily_stats", {}).get(day, 0))
    return day_count < max_replies_day


def increase_day_counter(state: dict) -> None:
    day = datetime.now().strftime("%Y-%m-%d")
    if "daily_stats" not in state:
        state["daily_stats"] = {}
    state["daily_stats"][day] = int(state["daily_stats"].get(day, 0)) + 1


def seconds_until_next_cycle(cycle_minutes: int, jitter_range: list[int]) -> int:
    jitter = random.randint(int(jitter_range[0]), int(jitter_range[1])) if jitter_range else 0
    return max(60, (cycle_minutes + jitter) * 60)


async def run_cycle(cfg: dict, profile: dict, state: dict, ollama: OllamaClient | None, persona: str, dry_run: bool) -> dict:
    logging.info("Starting cycle")

    seen = set(state.get("seen_posts", []))
    replied = set(state.get("replied_posts", []))
    keywords = resolve_keywords(cfg, persona, ollama, state)

    max_replies_cycle = int(profile["max_replies_per_cycle"])
    max_replies_day = int(profile["max_replies_per_day"])
    min_score = float(profile["llm_min_score"])
    search_per_kw = int(profile["search_posts_per_keyword"])

    stats = {
        "checked_posts": 0,
        "relevant_posts": 0,
        "replies_sent": 0,
        "keywords": keywords,
    }

    pw, context = await build_context(cfg)
    page = await context.new_page()

    try:
        for keyword in keywords:
            if stats["replies_sent"] >= max_replies_cycle:
                break
            if not can_reply_today(state, max_replies_day):
                logging.info("Daily reply limit reached")
                break

            logging.info("Search keyword: %s", keyword)
            posts = await scrape_posts_for_keyword(page, keyword, max_posts=search_per_kw)
            logging.info("Found posts: %s", len(posts))

            for post in posts:
                if stats["replies_sent"] >= max_replies_cycle:
                    break
                if not can_reply_today(state, max_replies_day):
                    break

                post_id = make_post_id(post.post_url, post.text)
                if post_id in seen:
                    continue
                seen.add(post_id)
                stats["checked_posts"] += 1

                if post_id in replied:
                    continue

                if ollama:
                    cls = ollama.classify(post.text, post.keyword)
                    if cls.get("reason") == "ollama_unavailable":
                        cls = simple_relevance_rule(post.text)
                else:
                    cls = simple_relevance_rule(post.text)

                is_relevant = bool(cls.get("relevant", False)) and float(cls.get("score", 0.0)) >= min_score
                if not is_relevant:
                    continue

                stats["relevant_posts"] += 1

                if ollama:
                    reply_text = ollama.compose_reply(persona, post.text, post.author_handle or "")
                else:
                    reply_text = "Interesting ask. I build IT/AI/app/web/telegram solutions and can help quickly. Want to continue in DM?"

                if not reply_text.strip():
                    reply_text = "Interesting ask. I build IT/AI/app/web/telegram solutions and can help quickly. Want to continue in DM?"

                if not reply_text.strip():
                    continue

                if dry_run:
                    ok, reason = True, "dry_run"
                else:
                    ok, reason = await post_reply(page, post.post_url, reply_text)

                state["reply_history"].append(
                    {
                        "ts": now_iso(),
                        "keyword": post.keyword,
                        "post_url": post.post_url,
                        "author": post.author_handle,
                        "decision": cls,
                        "reply": reply_text,
                        "status": "sent" if ok else "failed",
                        "reason": reason,
                    }
                )

                if ok:
                    replied.add(post_id)
                    state["last_reply_ts"] = int(time.time())
                    increase_day_counter(state)
                    stats["replies_sent"] += 1
                    logging.info("Reply sent to %s | %s", post.author_handle, post.post_url)
                else:
                    logging.warning("Reply failed: %s", reason)

                delay_rng = profile.get("reply_delay_seconds", [25, 90])
                await asyncio.sleep(random.randint(int(delay_rng[0]), int(delay_rng[1])))

    finally:
        await context.storage_state(path=str(STORAGE_STATE_FILE))
        await context.close()
        await pw.stop()

    state["seen_posts"] = dedupe_keep_tail(list(seen), 8000)
    state["replied_posts"] = dedupe_keep_tail(list(replied), 5000)
    state["reply_history"] = state.get("reply_history", [])[-4000:]

    logging.info(
        "Cycle done. checked=%s relevant=%s replies=%s",
        stats["checked_posts"],
        stats["relevant_posts"],
        stats["replies_sent"],
    )
    return stats


async def run_agent(args: argparse.Namespace) -> None:
    cfg = load_config()
    state = load_state()
    persona = load_persona(BASE_DIR / cfg.get("persona_file", PERSONA_FILE.name))

    profile_name = args.profile or cfg.get("profile", "safe")
    if profile_name not in PROFILE_PRESETS:
        raise RuntimeError(f"Unknown profile: {profile_name}")

    profile = dict(PROFILE_PRESETS[profile_name])
    profile.update(cfg.get("profile_overrides", {}))

    ollama = None
    if cfg.get("use_ollama", True):
        ollama = OllamaClient(
            host=cfg.get("ollama_host", "http://127.0.0.1:11434"),
            model=cfg.get("ollama_model", "llama3.1"),
            timeout_seconds=int(cfg.get("ollama_timeout_seconds", 45)),
        )

    logging.info("Agent profile=%s dry_run=%s", profile_name, args.dry_run)
    if args.once:
        await run_cycle(cfg, profile, state, ollama, persona, dry_run=args.dry_run)
        save_state(state)
        return

    while True:
        try:
            await run_cycle(cfg, profile, state, ollama, persona, dry_run=args.dry_run)
            save_state(state)
        except Exception as exc:
            logging.exception("Cycle error: %s", exc)

        wait_seconds = seconds_until_next_cycle(
            int(profile["cycle_minutes"]),
            profile.get("cycle_jitter_minutes", [1, 5]),
        )
        logging.info("Sleeping %s seconds", wait_seconds)
        await asyncio.sleep(wait_seconds)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Threads autopilot: find leads, filter, and reply")
    parser.add_argument("--setup-login", action="store_true", help="Open browser and save Threads login state")
    parser.add_argument("--once", action="store_true", help="Run one cycle and exit")
    parser.add_argument("--dry-run", action="store_true", help="Do not post replies, only simulate")
    parser.add_argument("--profile", choices=list(PROFILE_PRESETS.keys()), help="Run preset profile")
    parser.add_argument("--verbose", action="store_true", help="Verbose logs")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    setup_logging(args.verbose)

    try:
        cfg = load_config()
    except Exception as exc:
        print(exc)
        return

    if args.setup_login:
        asyncio.run(setup_login(cfg))
        return

    asyncio.run(run_agent(args))


if __name__ == "__main__":
    main()
