"""
Threads Scraper Bot
===================
Управление через Telegram: пишешь ключевик → бот скрапит Threads → присылает ссылки.
Все результаты сохраняются в notes.txt рядом со скриптом.

Команды:
  /start        — приветствие
  /help         — помощь
  /notes        — показать последние 20 сохранённых ссылок
  /clear        — очистить notes.txt
  любой текст   — поиск по этому ключевику в Threads
"""

import asyncio
import json
import logging
import os
import re
import sys
from datetime import datetime
from pathlib import Path
from urllib.parse import quote

from playwright.async_api import async_playwright

# ── telegram bot (python-telegram-bot v20+) ───────────────────────────────────
from telegram import Update
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    ContextTypes,
    filters,
)

# ── Конфиг ────────────────────────────────────────────────────────────────────
BASE      = Path(__file__).parent
NOTES     = BASE / "notes.txt"
COOKIES   = BASE / "threads_cookies.json"
CFG_FILE  = BASE / "config.json"

logging.basicConfig(
    format="%(asctime)s [%(levelname)s] %(message)s",
    level=logging.INFO,
    stream=sys.stdout,
)
log = logging.getLogger(__name__)


def load_cfg() -> dict:
    if not CFG_FILE.exists():
        print(f"\n[ОШИБКА] Нет config.json в {BASE}")
        print("         Скопируй config.example.json → config.json и заполни BOT_TOKEN\n")
        sys.exit(1)
    return json.loads(CFG_FILE.read_text(encoding="utf-8"))


def load_cookies() -> list:
    if COOKIES.exists():
        try:
            return json.loads(COOKIES.read_text(encoding="utf-8"))
        except Exception:
            pass
    return []


def save_cookies(cookies: list):
    COOKIES.write_text(json.dumps(cookies, ensure_ascii=False, indent=2), encoding="utf-8")


def append_notes(keyword: str, posts: list[dict]):
    with NOTES.open("a", encoding="utf-8") as f:
        f.write(f"\n\n=== {datetime.now().strftime('%Y-%m-%d %H:%M')}  |  {keyword} ===\n")
        for p in posts:
            url    = p.get("url", "")
            author = (p.get("author", "")
                      .replace("https://www.threads.net/@", "@")
                      .split("?")[0])
            text   = p.get("text", "")[:200].replace("\n", " ")
            line   = f"{url}  |  {author}  |  {text}"
            f.write(line + "\n")


# ── Скрапинг ──────────────────────────────────────────────────────────────────
async def scrape(keyword: str, max_results: int = 50) -> list[dict]:
    cookies = load_cookies()
    results = []

    async with async_playwright() as pw:
        browser = await pw.chromium.launch(headless=True)
        ctx = await browser.new_context(
            user_agent=(
                "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/124.0.0.0 Safari/537.36"
            )
        )
        if cookies:
            await ctx.add_cookies(cookies)

        page = await ctx.new_page()
        url  = f"https://www.threads.net/search?q={quote(keyword)}&serp_type=default"

        try:
            await page.goto(url, timeout=30000, wait_until="domcontentloaded")
            # Прокручиваем вниз несколько раз чтобы подгрузить больше постов
            for _ in range(6):
                await page.evaluate("window.scrollTo(0, document.body.scrollHeight)")
                await page.wait_for_timeout(1500)

            posts = await page.evaluate("""() => {
                const seen = new Set();
                const results = [];
                const articles = document.querySelectorAll('article, [role="article"]');
                for (const art of articles) {
                    const textEl = art.querySelector('[dir="auto"]');
                    const text = textEl ? textEl.innerText.trim() : '';
                    if (!text || text.length < 20) continue;
                    const linkEl = art.querySelector('a[href*="/post/"]');
                    const url = linkEl ? linkEl.href : '';
                    const key = url || text.slice(0, 80);
                    if (seen.has(key)) continue;
                    seen.add(key);
                    const authorEl = art.querySelector('a[href*="/@"]');
                    const author = authorEl ? authorEl.href : '';
                    results.push({ text, url, author });
                }
                return results;
            }""")

            # Fallback если article-теги не нашлись
            if not posts:
                posts = await page.evaluate("""() => {
                    const seen = new Set();
                    const results = [];
                    const els = document.querySelectorAll('[dir="auto"]');
                    for (const el of els) {
                        const text = el.innerText.trim();
                        if (text.length < 40) continue;
                        const a = el.closest('a');
                        const url = a ? a.href : '';
                        const key = url || text.slice(0, 80);
                        if (seen.has(key)) continue;
                        seen.add(key);
                        results.push({ text, url, author: '' });
                    }
                    return results.slice(0, 60);
                }""")

            results = [p for p in posts if p.get("text")][:max_results]
        except Exception as e:
            log.warning(f"scrape error: {e}")
        finally:
            await browser.close()

    return results


# ── Форматирование ответа ──────────────────────────────────────────────────────
def format_reply(keyword: str, posts: list[dict]) -> str:
    if not posts:
        return (
            f"🔍 «{keyword}» — постов не найдено.\n\n"
            "Возможные причины:\n"
            "• Нет авторизации в Threads (запусти setup.py)\n"
            "• Threads не показывает результаты без логина\n"
            "• Попробуй другой ключевик"
        )

    lines = [f"🔍 «{keyword}» — найдено {len(posts)} постов:\n"]
    for i, p in enumerate(posts, 1):
        url    = p.get("url", "")
        author = (p.get("author", "")
                  .replace("https://www.threads.net/@", "@")
                  .split("?")[0]) or "?"
        text   = p.get("text", "")[:120].replace("\n", " ")
        link   = f"[пост {i}]({url})" if url else f"пост {i}"
        lines.append(f"{i}. {link}  {author}\n   {text}")

    lines.append(f"\n✅ Сохранено в notes.txt")
    return "\n".join(lines)


# ── Handlers ──────────────────────────────────────────────────────────────────
async def cmd_start(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "Привет! Я Threads-скрапер.\n\n"
        "Просто напиши ключевик — и я найду посты на Threads по этой теме.\n\n"
        "Например:\n"
        "• нужен разработчик\n"
        "• ищу ai агента\n"
        "• hire developer\n\n"
        "/help — подробнее  |  /notes — сохранённые ссылки"
    )


async def cmd_help(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "📖 Как пользоваться:\n\n"
        "Напиши любой ключевик → получишь список постов с Threads + ссылки.\n"
        "Все результаты автоматически сохраняются в notes.txt.\n\n"
        "Команды:\n"
        "/notes — показать последние 20 сохранённых ссылок\n"
        "/clear — очистить notes.txt\n\n"
        "Примеры ключевиков:\n"
        "• нужен разработчик\n"
        "• ищу it специалиста\n"
        "• looking for developer\n"
        "• build telegram bot\n"
        "• нужна разработка приложения"
    )


async def cmd_notes(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not NOTES.exists() or NOTES.stat().st_size == 0:
        await update.message.reply_text("📝 notes.txt пустой.")
        return
    text = NOTES.read_text(encoding="utf-8")
    lines = text.strip().splitlines()
    # последние 30 строк
    snippet = "\n".join(lines[-30:])
    await update.message.reply_text(f"📝 Последние записи из notes.txt:\n\n{snippet[:3800]}")


async def cmd_clear(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    NOTES.write_text("", encoding="utf-8")
    await update.message.reply_text("🗑 notes.txt очищен.")


async def on_keyword(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    keyword = update.message.text.strip()
    if not keyword:
        return

    await update.message.reply_text(f"🔄 Ищу «{keyword}» на Threads, подожди 20–40 сек...")

    posts = await scrape(keyword, max_results=50)

    if posts:
        append_notes(keyword, posts)

    reply = format_reply(keyword, posts)
    # telegram limit 4096, split if needed
    if len(reply) <= 4096:
        await update.message.reply_text(reply, parse_mode="Markdown",
                                         disable_web_page_preview=True)
    else:
        for chunk in [reply[i:i+4000] for i in range(0, len(reply), 4000)]:
            await update.message.reply_text(chunk, parse_mode="Markdown",
                                             disable_web_page_preview=True)


# ── Setup auth ────────────────────────────────────────────────────────────────
async def setup_auth():
    print("\n[SETUP] Открываю браузер — войди в threads.net, затем нажми Enter.\n")
    async with async_playwright() as pw:
        browser = await pw.chromium.launch(headless=False)
        ctx     = await browser.new_context()
        page    = await ctx.new_page()
        await page.goto("https://www.threads.net/login", timeout=30000)
        input("[SETUP] Нажми Enter после входа в аккаунт... ")
        cookies = await ctx.cookies()
        save_cookies(cookies)
        await browser.close()
    print(f"[SETUP] Сессия сохранена → {COOKIES}")
    print("[SETUP] Теперь запускай: python bot.py\n")


# ── Main ──────────────────────────────────────────────────────────────────────
def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--setup", action="store_true",
                        help="Авторизоваться в Threads (первый запуск)")
    args = parser.parse_args()

    if args.setup:
        asyncio.run(setup_auth())
        return

    cfg = load_cfg()
    token = cfg.get("bot_token", "")
    if not token or token == "ВСТАВЬ_ТОКЕН_БОТА":
        print("[ОШИБКА] Заполни bot_token в config.json")
        sys.exit(1)

    print(f"[СТАРТ] Бот запущен. Жди сообщений...")
    app = Application.builder().token(token).build()
    app.add_handler(CommandHandler("start", cmd_start))
    app.add_handler(CommandHandler("help",  cmd_help))
    app.add_handler(CommandHandler("notes", cmd_notes))
    app.add_handler(CommandHandler("clear", cmd_clear))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, on_keyword))
    app.run_polling(drop_pending_updates=True)


if __name__ == "__main__":
    main()
