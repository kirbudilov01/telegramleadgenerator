#!/bin/bash
# Threads Bot — Установка
# Запусти один раз: bash setup.sh

set -e
cd "$(dirname "$0")"

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Threads Scraper Bot  [Setup]"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

if ! command -v python3 &>/dev/null; then
  echo "[ОШИБКА] Python3 не найден."
  echo "         macOS: brew install python"
  echo "         или скачай с https://python.org"
  exit 1
fi

echo "[1/3] Python: $(python3 --version)"

if [ ! -d "venv" ]; then
  echo "[2/3] Создаю venv..."
  python3 -m venv venv
else
  echo "[2/3] venv уже есть"
fi

source venv/bin/activate
echo "[3/3] Устанавливаю зависимости..."
pip install -q -r requirements.txt
playwright install chromium

if [ ! -f "config.json" ]; then
  cp config.example.json config.json
fi

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Установка готова!"
echo ""
echo "  ШАГИ:"
echo ""
echo "  1. Открой config.json и вставь bot_token"
echo "     (получи у @BotFather: /newbot)"
echo ""
echo "  2. Один раз войди в Threads через браузер:"
echo "     source venv/bin/activate"
echo "     python bot.py --setup"
echo ""
echo "  3. Запусти бота:"
echo "     python bot.py"
echo ""
echo "  4. Напиши боту в Telegram любой ключевик,"
echo "     например: нужен разработчик"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
